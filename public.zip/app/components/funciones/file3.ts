
const letras = ['c', 'b', 'a'];

function order(x: string[]) {
    x.sort();
    console.log('alphaNumeric :' + x );


  }

  order(letras);
