const a = [ 7, 4, 17, 10, 48];
const b = [ 7, 4, 17, 10, 48];

function add(x: number[], y: number[]): number[] {
    const Z = x.concat(y); 
    console.log('alphaNumeric :' + Z );
    return Z;

  }

  add(a,b);

