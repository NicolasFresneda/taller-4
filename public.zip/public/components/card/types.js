export var CardAttributes;
(function (CardAttributes) {
    CardAttributes["title"] = "title";
    CardAttributes["description"] = "description";
})(CardAttributes || (CardAttributes = {}));
export var CardEvents;
(function (CardEvents) {
    CardEvents["cardSelected"] = "cardSelected";
})(CardEvents || (CardEvents = {}));
